// ***************************************
// *                                     *
// *      EasyCTF 2014 CTF-Platform      *
// *                                     *
// ***************************************

const express = require("express");
const http = require("http");
const api = require("./api/api");
const router = require("./app/router");
require("dotenv").config();

const app = express();

// Set application settings
app.set("port", process.env.PORT || 3001);
app.set("views", __dirname + "/app/jade");
app.set("view engine", "jade");
app.locals.pretty = true;

// Middleware
app.use(express.json()); // Replaces express.bodyParser()
app.use(express.urlencoded({ extended: true })); // Replaces express.bodyParser()
app.use(require("cookie-parser")()); // Replaces express.cookieParser()
app.use(require("method-override")("_method")); // Replaces express.methodOverride()

// Ensure the secret is provided
app.use(
  require("express-session")({
    secret: process.env.APP_SECRET || "your-default-secret", // Provide a fallback secret
    resave: false,
    saveUninitialized: true,
  })
);

// Static files
app.use(express.static(__dirname + "/web"));

// Initialize API and router
api(app);
router(app);

// Start the server
http.createServer(app).listen(app.get("port"), function () {
  console.log("Server listening on port " + app.get("port") + "...");
});
