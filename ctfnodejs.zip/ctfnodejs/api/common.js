const { MongoClient } = require("mongodb");
const url = "mongodb://localhost:27017";
const dbName = "ctf";
var entities_ = require("html-entities").XmlEntities;

var entities = new entities_();
let db;

// Create a new MongoClient
const client = new MongoClient(url);

async function connectToDatabase() {
  try {
    // Connect the client to the server
    await client.connect();
    console.log("[api/common.js] connected to database");

    // Get the database
    db = client.db(dbName);
    // Check if collection is defined
    if (!db) {
      throw new Error("Failed to get the collection.");
    }
    // Authentication (if needed)
    // Note: Authentication is handled differently in newer MongoDB versions.
    const collection = db.collection("users"); // Change 'users' to your collection name

    // Check if collection is defined
    if (!collection) {
      throw new Error("Failed to get the collection.");
    }

    // Perform your operations
    const result = await collection.find({}).toArray();
    console.log("Documents:", result);
  } catch (err) {
    console.error("[api/common.js] error connecting to database", err);
  }
}

// Call the function to connect
connectToDatabase();

// Export the db object
exports.db = db;

exports.validatePassword = function (plain, hashed) {
  var salt = hashed.substr(0, exports.HASH_LENGTH);
  var valid = salt + exports.hash(plain + salt, "sha256");
  return hashed === valid;
};

exports.generateSalt = function () {
  var set = "0123456789abcdefghijklmnopqurstuvwxyzABCDEFGHIJKLMNOPQURSTUVWXYZ";
  var salt = "";
  for (var i = 0; i < exports.HASH_LENGTH; i++) {
    var p = Math.floor(Math.random() * set.length);
    salt += set[p];
  }
  return salt;
};

exports.hash = function (str, algo) {
  return crypto.createHash(algo).update(str).digest("hex");
};

exports.encryptPass = function (pass) {
  var salt = exports.generateSalt();
  return salt + exports.hash(pass + salt, "sha256");
};

exports._ = function (str) {
  return entities.encode(str).trim();
};
